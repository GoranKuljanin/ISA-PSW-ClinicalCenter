import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-lista-pacijenata',
  templateUrl: './lista-pacijenata.component.html',
  styleUrls: ['./lista-pacijenata.component.css']
})
export class ListaPacijenataComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
