import { AppRoutingModule } from './../../app-routing.module';
import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-admin-klinickog-centra-home-page',
  templateUrl: './admin-klinickog-centra-home-page.component.html',
  styleUrls: ['./admin-klinickog-centra-home-page.component.css']
})
export class AdminKlinickogCentraHomePageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
