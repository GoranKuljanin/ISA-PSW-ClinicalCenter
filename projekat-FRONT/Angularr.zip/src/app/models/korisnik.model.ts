export class Korisnik {
    // adresaKorisnik: string;
    // drzavaKorisnik: string;
    // emailKorisnik: string;
    // gradKorisnik:string;
    // idKorisnik: number;
    // imeKorisnik:string;
    // lozinkaKorisnik:string;
    // prezimeKorisnik:string;
    // brojKorisnik:string;
}
