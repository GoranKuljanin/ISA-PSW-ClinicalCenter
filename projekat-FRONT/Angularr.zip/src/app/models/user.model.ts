export class User {
    username: string;
    lastname: string;
    email: string;
    password: string;
    adress: string;
    city: string;
    country: string;
    state: string;
    phoneNumber: string;
    uloga: string;

    //constructor(uloga : string){ this.uloga = uloga}
}
