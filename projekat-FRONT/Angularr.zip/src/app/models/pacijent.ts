import { User } from './user.model';
export class Pacijent {
    zdravstveniKarton:string;
    user:User;
}
