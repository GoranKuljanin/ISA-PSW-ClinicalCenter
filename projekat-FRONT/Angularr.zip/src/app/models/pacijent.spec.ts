import { Pacijent } from './pacijent';

describe('Pacijent', () => {
  it('should create an instance', () => {
    expect(new Pacijent()).toBeTruthy();
  });
});
