export class Sala{
    id:number;
    name:string;
}