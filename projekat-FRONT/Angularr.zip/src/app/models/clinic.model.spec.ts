import { Clinic } from './clinic.model';

describe('Clinic', () => {
  it('should create an instance', () => {
    expect(new Clinic()).toBeTruthy();
  });
});
